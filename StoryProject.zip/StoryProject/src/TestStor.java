import Company.Airconditioner;
import Company.Company;
import Company.FoodRestaurant;

public class TestStor {

	public static void main(String[] args) {
		Company comObj = new Company(101, "xyz");
		comObj.showDetails();
		
		Airconditioner ac1 = new Airconditioner("VOLTAS", 1);
		ac1.cool();
		
		
		FoodRestaurant fr = new FoodRestaurant();
		fr.Eat();
		
		
		
		
	
	}
	

}
