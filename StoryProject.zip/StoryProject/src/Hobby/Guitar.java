package Hobby;

class Guitar implements Playing
{

	@Override
	public void play() {
		System.out.println("Kids are Playing guitar ");	 
		
	}
	

}
interface Playing
{
		void play();

}

