package Company;

public class Company 
{
	int regNumber;
	String name;
	public Company(int regNumber, String name) {
		super();
		this.regNumber = regNumber;
		this.name = name;
	}
	
	public void showDetails()
	{
		System.out.println("Details of the company     :"+regNumber+","+name);
	}
	
	
}
