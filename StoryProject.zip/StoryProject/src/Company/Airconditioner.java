package Company;

interface Cooling
{
		void cool();
		
}

 public class Airconditioner implements Cooling
{
	String brandName;
	float ton;
	public Airconditioner(String brandName, float ton) {
		super();
		this.brandName = brandName;
		this.ton = ton;
	}
	@Override
	public void cool() {
		System.out.println("AC is Cooling the Room");		
	}
	
}
