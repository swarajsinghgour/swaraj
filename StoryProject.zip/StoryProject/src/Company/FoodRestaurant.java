package Company;

public class FoodRestaurant extends Company implements Eating
{

	public FoodRestaurant() {
		super(101, "zomato");
		System.out.println("Welcome to Food Restaurant   :"+name);
	}
	
	
	
	
}
class KFC extends FoodRestaurant
{

	public KFC() {
		super();
		
		System.out.println("what are you doing");
	}

	
	

}
interface Eating
{
	
	default void Eat() {
		
		System.out.println("Eating");
	}
	

}