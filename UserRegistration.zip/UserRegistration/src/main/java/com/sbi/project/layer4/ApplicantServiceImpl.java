package com.sbi.project.layer4;
import com.sbi.project.layer2.*;
import com.sbi.project.layer3.*;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.sbi.layer2.Applicant;
//import com.sbi.layer3.ApplicantRepository;
//import com.sbi.layer3.ApplicantRepositoyImpl;

@Service
public class ApplicantServiceImpl implements ApplicantService 
{
	@Autowired
	ApplicantRepository appRepo;
	
	@Autowired
	MailService mailServ;
	
	@Override
	public String createApplicationService(Applicant app) {
		
		String status = "Failed";		
		if(Period.between(app.getApplicantBirthDate(), LocalDate.now()).getYears() < 18) {
			status = "DOB Invalid";
		}
		else
		{
			appRepo.createApplicant(app);
			if(app.getApplicantId() > 0) {
				status = "Service Request Number : SBI_" + app.getApplicantId()+"_" + LocalDate.now();
				mailServ.sendMail(status, app.getEmailId());
			}
		}
		 return status;
	}

	public List<Applicant> getAllApplicants() {
		return appRepo.findAllApplicants();
	}

	@Override
	public void removeApplicant(int applicantId) {
		// TODO Auto-generated method stub
		appRepo.removeApplicant(applicantId);
		System.out.println("Applicant serviceImpl{} removed");
	}

	@Override
	public void modifyApplicant(Applicant applicant) {
		// TODO Auto-generated method stub
		appRepo.modifyApplicant(applicant);
	}

	@Override
	public Applicant findApplicant(int applicantId) {
		// TODO Auto-generated method stub
		return appRepo.findApplication(applicantId);
	}
}
