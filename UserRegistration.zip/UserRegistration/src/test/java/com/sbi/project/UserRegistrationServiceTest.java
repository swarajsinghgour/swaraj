package com.sbi.project;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.ApplicantService;

@SpringBootTest
public class UserRegistrationServiceTest {

	@Autowired
	ApplicantService appService;
	
	@Test
	void createApplicantServiceTest()
	{
		Applicant applicant = new Applicant();
		applicant.setSalutation("Er");
		applicant.setApplicantName("ramaswami");
		applicant.setApplicantFatherName("Lhinaswami");
		applicant.setApplicantBirthDate(LocalDate.of(2009, 5, 4));
		applicant.setApplicantGender("M");
		applicant.setEmailId("Duraiswami@gmail.com");
		applicant.setMobileNumber(8475456421l);
		applicant.setApplicantAadhar(426355741308l);
		applicant.setApplicantPan("TYRYD5579Q");
		applicant.setApplicantOccupation("Professional");
		applicant.setApplicantAnnualIncome(504000l);
		applicant.setApplicationStatus("Applied");
		applicant.setMarried("Single");
		applicant.setAddress("B-44, Sector-29,Belapur, Navi Mumbai");
		
		appService.createApplicationService(applicant);
	}
	
	@Test
	void showAllApplicantServiceTest()
	{
		List<Applicant> applicant = appService.getAllApplicants();
		for(Applicant appl : applicant)
		{
			System.out.println(appl);
		}
	}
	
	@Test
	void findApplicantServiceTest()
	{
		Applicant applicant = appService.findApplicant(16);
		
		Assertions.assertTrue(applicant!=null);
		System.out.println(applicant);
		
	}
	
	@Test
	void updateApplicantServiceTest()
	{
        Applicant applicant = appService.findApplicant(16);
		
		Assertions.assertTrue(applicant!=null);
		applicant.setMobileNumber(8475456532l);
		applicant.setApplicantAadhar(426355741367l);
		applicant.setApplicantPan("TYRYD5579R");
		appService.modifyApplicant(applicant);
		
	}
	
	@Test
	void deleteApplicant()
	{
		Applicant applicant = appService.findApplicant(16);
		
		Assertions.assertTrue(applicant!=null);
		appService.removeApplicant(applicant.getApplicantId());
	}
	
}