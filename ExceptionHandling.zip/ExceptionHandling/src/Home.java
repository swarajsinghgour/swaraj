
public class Home {

	public static void main(String[] args) 
	{
		System.out.println("Main");
		
		Door drObj1 = new Door(1, "Swarag", "123");
		
		HomeKey key1 = new HomeKey("123");
		
		Owner own1 = new Owner();
		
		try
		{
			own1.enterTheHome(drObj1, key1);
		}
		catch(LockException e)
		{
			System.out.println("Lock problem :"+e);
		}
		catch(UnLockException e)
		{
			System.out.println("Unlock problem  :"+e);
		}
		
		System.out.println("Door 1"+drObj1);
		
	}

}

abstract class Key
{
	String code;
	abstract void open();
	abstract void close();
}

class HomeKey extends Key
{

	
	
	public HomeKey(String code) {
		super();
		this.code= code;
	
	}

	@Override
	void open() {
		System.out.println("Open the Door");
		
	}

	@Override
	void close() {
		System.out.println("Close the Door");
				
	}
	

}
abstract class Lock
{
	String code;
	abstract void lock();
	abstract void unLock();
	

}

class DoorLock extends Lock
{

	public DoorLock(String code) {
		super();
		this.code=code;
		
	}
	
	
	void lock() {
		System.out.println("Door is locked");
		
	}

	@Override
	void unLock() {
		System.out.println("Door is unlocked");
		
	}

}

abstract class GateKeeper
{
	abstract void enterTheHome(Door door, Key key) throws LockException, UnLockException ;

}

class LockException extends Exception
{
	LockException(String str) {
		super(str);
	}
}
class UnLockException extends Exception
{
	UnLockException(String str) {
		super(str);
	}
}
class Owner extends GateKeeper
{

	

	@Override
	void enterTheHome(Door door, Key key) throws LockException, UnLockException 
	{
		Door hm = (Door) door;
		if(hm.lock.code.equals(key.code))
		{
			hm.lock.unLock();
		}
		else
		{
			throw new UnLockException("Unable to unlock");
		}
	
		key.open();
		
		if(hm.lock.code.equals(key.code))
		{
			hm.lock.unLock();
		}
		else
		{
			throw new LockException("Unable to lock");
		}
	
	}
	
	
}
class EntryPoint{
	
}

class Door extends EntryPoint
{
	int DoorId;
	String DoorName;
	boolean keyStatus;
	Lock lock;
	public Door(int doorId, String doorName, String code) {
		super();
		DoorId = doorId;
		DoorName = doorName;
		
		lock = new DoorLock(code);
	}
	@Override
	public String toString() {
		return "Door [DoorId=" + DoorId + ", DoorName=" + DoorName + ", keyStatus=" + keyStatus + ", lock=" + lock
				+ ", toString()=" + super.toString() + "]";
	}
	
	
	
}
